#define VERSION		"2.4.7"
#define DATE		"9 August 2014"
